import { Router } from "express";
import { asyncHandler } from "../../utils/errorhandling/asynchandler.js";
import * as adminService from "./admin.service.js";
import authAction from "../../middleware/authaction.middleware.js";
import { authorization } from "../../middleware/authorization.middleware.js";
import { adminEndpoint } from "./admin.endpoint.js";
import { validation } from "../../middleware/validation.middleware.js";
import { updateRequestStatusSchema } from "../donation/donation.validation.js";

const router = Router();

// GET /admin/donations
router.get("/donations", authAction, authorization(adminEndpoint.getPendingDonations), asyncHandler(adminService.getPendingDonations));

// PATCH /admin/donation/:id
router.patch("/donation/:id", authAction, authorization(adminEndpoint.updateDonationStatus), validation(updateRequestStatusSchema), asyncHandler(adminService.updateDonationStatus));

export default router;