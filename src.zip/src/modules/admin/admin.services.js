import { donationModel, donationStatus } from "../../database/model/donation.model.js";
import { charityModel } from "../../database/model/charity.model.js";
import { notificationModel } from "../../database/model/notification.model.js";
import { advancedPagination } from "../../middleware/pagination.middleware.js";

// ===================== 1) Get Pending Donations =====================
export const getPendingDonations = async (req, res, next) => {
  const charity = await charityModel.findOne({ userId: req.user._id });
  if (!charity) return next(new Error("Charity not found", { cause: 404 }));

  const data = await advancedPagination(donationModel, {
    charityId: charity._id,
    status: donationStatus.pending,
  });
  return res.status(200).json({ success: true, data });
};

// ===================== 2) Approve or Reject Donation =====================
export const updateDonationStatus = async (req, res, next) => {
  const { id } = req.params;
  const { status } = req.body;

  const charity = await charityModel.findOne({ userId: req.user._id });
  if (!charity) return next(new Error("Charity not found", { cause: 404 }));

  const donation = await donationModel.findOne({ _id: id, charityId: charity._id });
  if (!donation) return next(new Error("Donation not found", { cause: 404 }));

  if (donation.status !== donationStatus.pending)
    return next(new Error("Donation already processed", { cause: 400 }));

  const updated = await donationModel.findByIdAndUpdate(
    id,
    { status },
    { new: true }
  );

  await notificationModel.create({
    userId: donation.donorId,
    donationId: donation._id,
    content: status === donationStatus.accepted
      ? "✅ تم قبول تبرعك من قبل الأدمن"
      : "❌ تم رفض تبرعك من قبل الأدمن",
    status: notificationStatus.unread,
  });

  return res.status(200).json({
    success: true,
    message: "Donation status updated",
    donation: updated,
  });
};